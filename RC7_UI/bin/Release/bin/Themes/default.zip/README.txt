README
 * GUIDE: CUSTOM THEMES FOR RC7
 * All Files requried to be in .bmp format
 * Gfx must be placed in C:\RC7_THEMES
 * Your gfx must correspond to one of the names below or it wont work 
 * You can change text color in Config.txt, i.e. FontColor:255,0,0; Uses RGB, in this case red
 * You can download themes at http://drive.google.com/file/d/0BzhRkdOa-AU2UWtsa05RMm5yd3c/
 ********************************************************
 (Gfx -> Filename)
 *RC7 background -> MainUi.bmp
 *Buttons IDLE -> S_Button_Idle.bmp
 *Buttons HOVER -> S_Button_Hover.bmp
 *Buttons CLICKED -> S_Button_Clicked.bmp
 *AutoRun CLICKED -> Auto_In.bmp
 *WordWrap CLICKED -> WordWrap_In.bmp
 *Wolf CLICKED -> Wolfy_In.bmp
 *Ro-Xploit CLICKED -> Krystal_In.bmp
 *Google Drive CLICKED -> Google_Drive_In.bmp
 *Save Button CLICKED -> Save_In.bmp
 *TextBox -> TextBox.bmp
 *Hide_Side -> Hide_Side.bmp
 *Submit button IDLE -> Button_Idle.bmp
 *Submit button HOVER -> Button_Hover.bmp
 *Submit button CLICKED -> Button_Clicked.bmp.bmp
